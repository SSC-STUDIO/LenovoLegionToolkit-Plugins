#pragma once

namespace Nilesoft
{
	namespace Shell
	{
		/*class Styles
		{
		public:
			bool Enable = false;

			int	MaxHeight = -1;
			int MaxWidth = -1;
			int	MinHeight = -1;
			int MinWidth = -1;
			int	Height = -1;
			int Width = -1;

			COLORREF FontColor = 0;
			COLORREF FontSelColor = 0;
			COLORREF BackColor = 0;
			COLORREF BackSelColor = 0;

			int FontSize = -1;
			int FontWeight = 0;//0 normal, 2 bold
			int FontStyle = 0; //0 normal, 1 italic, 2 oblique

			int TextAlign = 0; // 0 left, 1 right, 2 center

		};*/
	}
}