using System.Runtime.Versioning;

[assembly: SupportedOSPlatform("windows")]
